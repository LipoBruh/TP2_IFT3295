Émanuel Rollin -20106951

if needed:

`node install`

then 

`npm tp2_q2.js`


Q1 is done
Q2.1 and Q2.2 are done
Q2.3 and Q2.4 and partially done but fail (bad output)
Q2.5 is missing

Q3.1 is done
Q3.2 is missing (lack of valid data from Q2)

Also available on github 
https://github.com/LipoBruh/TP2_IFT3295